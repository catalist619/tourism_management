-- Active: 1714993207096@@127.0.0.1@5432@tours_management@public

CREATE TABLE tblfeedback (
    id SERIAL PRIMARY KEY NOT NULL,
    guest_name VARCHAR (100) NOT NULL,
    guest_email VARCHAR (200) NOT NULL,
    feedback_type VARCHAR (300) NOT NULL,
    feedback_desc VARCHAR (1000) NOT NULL,
    feedback_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE "tblbooking" ADD COLUMN "place" VARCHAR(255) NOT NULL ;

INSERT INTO admin (id, username, password) VALUES (1, 'catalist', 'catalist');

UPDATE TABLE admin set password='admin' where id=1;