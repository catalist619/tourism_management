CREATE TABLE admin(
    id SERIAL NOT NULL,
    username varchar(100) NOT NULL,
    password varchar(100) NOT NULL,
    PRIMARY KEY(id)
);

CREATE TABLE tblbooking(
    bookingid SERIAL NOT NULL,
    useremail varchar(100) NOT NULL,
    fromdate varchar(100) NOT NULL,
    todate varchar(100) NOT NULL,
    comment text NOT NULL,
    regdate timestamp without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    status integer NOT NULL,
    updationdate timestamp without time zone,
    PRIMARY KEY(bookingid)
);

CREATE TABLE tblfeedback(
    id SERIAL NOT NULL,
    guest_name varchar(100) NOT NULL,
    guest_email varchar(200) NOT NULL,
    feedback_type varchar(300) NOT NULL,
    feedback_desc varchar(1000) NOT NULL,
    feedback_date timestamp without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY(id)
);

CREATE TABLE tblusers(
    id SERIAL NOT NULL,
    fullname varchar(100) NOT NULL,
    mobilenumber character(10) NOT NULL,
    emailid varchar(100) NOT NULL,
    password varchar(100) NOT NULL,
    regdate timestamp without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updationdate timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY(id)
);