<?php
include('includes/config.php');

if (isset($_POST['user_id'])) {
    $user_id = intval($_POST['user_id']);
    
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['new_password'])) {
        $new_password = $_POST['new_password'];
        
        $query = "UPDATE tblusers SET password = $1, updationdate = NOW() WHERE id = $2";
        $result = pg_query_params($conn, $query, array($new_password, $user_id));
        
        if ($result) {
            echo "Password updated successfully.";
        } else {
            echo "Error updating password.";
        }
    } else {
        ?>
        <form method="post" action="manage-users.php">
            <input type="hidden" name="user_id" value="<?php echo htmlentities($user_id); ?>">
            <label for="new_password">New Password:</label>
            <input type="password" name="new_password" required>
            <input type="submit" value="Change Password">
        </form>
        <?php
    }
} else {
    echo "No user ID provided.";
}
?>
