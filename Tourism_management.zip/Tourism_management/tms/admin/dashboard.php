<?php
session_start();
include('includes/config.php');
if(isset($_SESSION['alogin'])==0) {	
    header('location:index.php');
}
?>
<!DOCTYPE HTML>
<html>
<head>
    <title>TMS | Admin Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <script type="application/x-javascript"> 
        addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); 
        function hideURLbar(){ window.scrollTo(0,1); } 
    </script>
    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
    <!-- Custom CSS -->
    <link href="css/style.css" rel='stylesheet' type='text/css' />
    <link rel="stylesheet" href="css/morris.css" type="text/css"/>
    <!-- Graph CSS -->
    <link href="css/font-awesome.css" rel="stylesheet"> 
    <!-- jQuery -->
    <script src="js/jquery-2.1.4.min.js"></script>
    <!-- //jQuery -->
    <link href='//fonts.googleapis.com/css?family=Roboto:700,500,300,100italic,100,400' rel='stylesheet' type='text/css'/>
    <link href='//fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
    <!-- lined-icons -->
    <link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
    <!-- //lined-icons -->
	<style>
/* Style for table */
table {
    width: 100%;
    border-collapse: collapse;
    border: 2px solid #ADD8E6; /* Light blue border */
}

/* Style for table header */
th {
    background-color: #ADD8E6; /* Light blue background */
    color: #FFFFFF; /* White text */
    text-align: left;
    padding: 10px;
    font-weight: bold;
    border-bottom: 2px solid #ADD8E6; /* Light blue border */
}

/* Style for table rows */
tr:nth-child(even) {
    background-color: #F0F8FF; /* Light blue background */
}

tr:hover {
    background-color: #B0E0E6; /* Lighter hover color */
}

/* Style for table cells */
td {
    padding: 10px;
    border-bottom: 1px solid #ADD8E6; /* Light blue border */
}

/* Style for delete and change password buttons */
input[type="submit"] {
    background-color: #FFFFFF; /* White background */
    color: #000000; /* Black text */
    border: 1px solid #ADD8E6; /* Light blue border */
    padding: 5px 10px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    margin: 2px 0px;
    cursor: pointer;
    border-radius: 4px;
}

input[type="submit"]:hover {
    background-color: #B0E0E6; /* Lighter blue on hover */
}
</style>



</head> 
<body>
   <div class="page-container">
       <!--/content-inner-->
       <div class="left-content">
           <div class="mother-grid-inner">
               <!--header start here-->
               <?php include('includes/header.php');?>
               <!--header end here-->
               <ol class="breadcrumb">
                   <li class="breadcrumb-item"><a href="dashboard.php">Home</a> <i class="fa fa-angle-right"></i></li>
               </ol>
               <!-- All bookings start-->
               <div class="agile-grids">	
                   <!-- tables -->
                   <div class="agile-tables">
                       <div class="w3l-table-info">
                           <h2>Bookings</h2>
                           <?php if (isset($message)) { echo "<div class='alert alert-success'>$message</div>"; } ?>
                           <table id="table">
                               <thead>
                                   <tr>
                                       <th>#</th>
                                       <th>User Email</th>
                                       <th>From Date</th>
                                       <th>To Date</th>
                                       <th>Comment</th>
                                       <th>RegDate</th>
                                       <th>Place</th>
                                   </tr>
                               </thead>
                               <tbody>
                                   <?php
                                   $query_bookings = "SELECT * FROM tblbooking";
                                   $result_bookings = pg_query($conn, $query_bookings);
                                   $cnt = 1;
                                   while ($row_booking = pg_fetch_assoc($result_bookings)) {
                                       echo "<tr>
                                               <td>" . htmlspecialchars($cnt) . "</td>
                                               <td>" . htmlspecialchars($row_booking['useremail']) . "</td>
                                               <td>" . htmlspecialchars($row_booking['fromdate']) . "</td>
                                               <td>" . htmlspecialchars($row_booking['todate']) . "</td>
                                               <td>" . htmlspecialchars($row_booking['comment']) . "</td>
                                               <td>" . htmlspecialchars($row_booking['regdate']) . "</td>
                                               <td>" . htmlspecialchars($row_booking['place']) . "</td>
                                           </tr>";
                                       $cnt++;
                                   }
                                   ?>
                               </tbody>
                           </table>
                       </div>
                   </div>
               </div>
               <!-- all booking end -->
               <!-- All feedback start -->
               <div class="agile-grids">	
                   <!-- tables -->
                   <div class="agile-tables">
                       <div class="w3l-table-info">
                           <h2>Feedback</h2>
                           <?php if (isset($message)) { echo "<div class='alert alert-success'>$message</div>"; } ?>
                           <table id="table">
                               <thead>
                                   <tr>
                                       <th>#</th>
                                       <th>Guest Name</th>
                                       <th>Guest Email</th>
                                       <th>Feedback Type</th>
                                       <th>Feedback Description</th>
                                       <th>Feedback Date</th>
                                   </tr>
                               </thead>
                               <tbody>
                                   <?php
                                   $query_feedback = "SELECT * FROM tblfeedback";
                                   $result_feedback = pg_query($conn, $query_feedback);
                                   $cnt = 1;
                                   while ($row_feedback = pg_fetch_assoc($result_feedback)) {
                                       echo "<tr>
                                               <td>" . htmlspecialchars($cnt) . "</td>
                                               <td>" . htmlspecialchars($row_feedback['guest_name']) . "</td>
                                               <td>" . htmlspecialchars($row_feedback['guest_email']) . "</td>
                                               <td>" . htmlspecialchars($row_feedback['feedback_type']) . "</td>
                                               <td>" . htmlspecialchars($row_feedback['feedback_desc']) . "</td>
                                               <td>" . htmlspecialchars($row_feedback['feedback_date']) . "</td>
                                           </tr>";
                                       $cnt++;
                                   }
                                   ?>
                               </tbody>
                           </table>
                       </div>
                   </div>
               </div>
               <!-- all feedback end -->
               <div class="inner-block">
               </div>
               <!--copy rights start here-->
               <?php include('includes/footer.php');?>
           </div>
       </div>
       <!--/sidebar-menu-->
       <?php include('includes/sidebarmenu.php');?>
       <div class="clearfix"></div>		
   </div>
   <script>
       var toggle = true;
       $(".sidebar-icon").click(function() {                
           if (toggle) {
               $(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
               $("#menu span").css({"position":"absolute"});
           } else {
               $(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
               setTimeout(function() {
                   $("#menu span").css({"position":"relative"});
               }, 400);
           }
           toggle = !toggle;
       });
   </script>
   <!--js -->
   <script src="js/jquery.nicescroll.js"></
