<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Form</title>
    <!-- Bootstrap CSS -->
    <link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
    <style>
        body {
            font-family: 'Open Sans', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .booking-container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
        .booking-container h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }
        .booking-container label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #555;
        }
        .booking-container input[type="text"],
        .booking-container input[type="email"],
        .booking-container input[type="date"],
        .booking-container textarea,
        .booking-container select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
            color: #333;
        }
        .booking-container textarea {
            resize: vertical;
            height: 100px;
        }
        .booking-container input[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #5cb85c;
            border: none;
            border-radius: 5px;
            font-size: 18px;
            color: #fff;
            cursor: pointer;
        }
        .booking-container input[type="submit"]:hover {
            background-color: #4cae4c;
        }
    </style>
</head>
<body>
    <div class="booking-container">
        <h2>Booking Form</h2>
        <form method="post">
            <div class="form-group">
                <label for="useremail">Email:</label>
                <input type="email" class="form-control" id="useremail" name="useremail" required>
            </div>
            
            <div class="form-group">
                <label for="fromdate">From Date:</label>
                <input type="date" class="form-control" id="fromdate" name="fromdate" required>
            </div>
            
            <div class="form-group">
                <label for="todate">To Date:</label>
                <input type="date" class="form-control" id="todate" name="todate" required>
            </div>

            <div class="form-group">
                <label for="place">Place to visit:</label>
                <select class="form-control" id="place_type" name="place" required>
                    <option value="" disabled selected>Choose here</option>
                    <option value="Stone Town Tour">Stone Town Tour</option>
                    <option value="Jozani Forest Tour">Jozani Forest Tour</option>
                    <option value="Safari Blue">Safari Blue</option>
                    <option value="Mikumi National Park">Mikumi National Park</option>
                    <option value="Ngorongoro Natinal Park">Ngorongoro Natinal Park</option>
                    <option value="Kilimanjaro Moutain">Kilimanjaro Mountain</option>
                </select>
            </div>
            
            <div class="form-group">
                <label for="comment">Comment:</label>
                <textarea class="form-control" id="comment" name="comment" required></textarea>
            </div>
            
            <button type="submit" class="btn btn-success">Book Now</button>
        </form>
    </div>

    <?php
    include('includes/config.php');

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Get form data
        $useremail = $_POST['useremail'];
        $fromdate = $_POST['fromdate'];
        $todate = $_POST['todate'];
        $comment = $_POST['comment'];
        $place = $_POST['place'];

        // SQL query to insert data into tblbooking
        $sql = "INSERT INTO tblbooking (useremail, fromdate, todate, comment, status, place) 
                VALUES ('$useremail', '$fromdate', '$todate', '$comment', 0, '$place')";

        // Execute the SQL statement with the form data
        $result = pg_query($conn, $sql);

        if ($result) {
            echo "<script>alert('Booking successful!');</script>";
        } else {
            echo "<script>alert('Booking failed: " . pg_last_error($conn) . "');</script>";
        }
    }
    ?>
</body>
</html>
