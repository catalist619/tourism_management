<?php
session_start();
error_reporting(0);
include('includes/config.php');

?>
<!DOCTYPE HTML>
<html>
<head>
<title>TMS | Tourism Management System</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Tourism Management System In PHP" />
<script type="applijewelleryion/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,700,600' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
<link href="css/font-awesome.css" rel="stylesheet">
<!-- Custom Theme files -->
<script src="js/jquery-1.12.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>
  <style>
		.errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
		</style>
</head>
<body>
<!-- top-header -->
<div class="top-header">
<?php include('includes/header.php');?>
<div class="banner-1 ">
	<div class="container">
		<h1 class="wow zoomIn animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: zoomIn;">TMS-Tourism Management System</h1>
	</div>
</div>
<div class="privacy">
	<div class="container">


  <div style="text-align: center;">
  <img loading="lazy" decoding="async" width="720" height="480" src="https://kwetumbalitours.com/wp-content/uploads/2024/01/kilimanjaro.png" sizes="(max-width: 720px) 100vw, 720px">													
  <p>Mt. Kilimanjaro 5895 meters above sea level is the highest mountain in Africa. It is one of the world's largest free-standing mountains. M.t Kilimanjaro ecosystem comprises five major ecological zones as follows, lower slopes, mountainous forests, heath and moorland, alpine desert, and the summit.
The Park can be reached by flying into KIA and driving through Moshi, although there are various options to climb to the snow-peaked dome of Mt. Kilimanjaro, most hikers use Marangu Trail, which is climbable without special equipment. Other routes include Machame, Umbwe, Mweka, Rongai, Shira Plateau (Londorosi Gate), Great Western Breach, Mawenzi Peak, and Summit Circuits. Tents are used for accommodation in all these routes. Any physically fit person from a 13-year-old to an 80-year-old can climb this world's heritage mountain site to the top. The minimum days to reach the summit are 5 days spending 4 nights.
Accommodation: Huts & Campsites on the mountain. Several hotels and campsite outside the park
Best Time: Warmest conditions from December-February & Colder condition from July- September.</p> <br> <br>
  </div>
	<center>	<h3 class="wow fadeInDown animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInDown;">BOOKING FORM</h3>

<?php include("booking.php") ?>
</center>
		
	</div>
</div>

<?php include('includes/footer.php');?>
<?php include('includes/signup.php');?>			
<?php include('includes/signin.php');?>			
<?php include('includes/write-us.php');?>

</body>
</html>