<?php
session_start();
error_reporting(0);
include('includes/config.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $guest_name = $_POST['guest_name'];
    $guest_email = $_POST['guest_email'];
    $feedback_type = $_POST['feedback_type'];
    $feedback_desc = $_POST['feedback_desc'];

    // Prepare SQL query to insert data into tblfeedback
    $sql = "INSERT INTO tblfeedback (guest_name, guest_email, feedback_type, feedback_desc) 
            VALUES ('$guest_name', '$guest_email', '$feedback_type', '$feedback_desc')";

    // Execute the SQL statement with the form data
    $result = pg_query($conn, $sql);

    if ($result) {
        echo "<script>alert('Feedback submitted successfully');</script>";
    } else {
        echo "<script>alert('Feedback submission failed: " . pg_last_error($conn) . "');</script>";
    }
}
?>


<!DOCTYPE HTML>
<html>
<head>
    <title>Feedback Form | TMS</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
    <link href="css/style.css" rel='stylesheet' type='text/css' />
    <link href='//fonts.googleapis.com/css?family=Open+Sans:400,700,600' rel='stylesheet' type='text/css'>
    <link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
    <link href='//fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
    <link href="css/font-awesome.css" rel="stylesheet">
    <script src="js/jquery-1.12.0.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <!--animate-->
    <link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
    <script src="js/wow.min.js"></script>
    <script>
        new WOW().init();
    </script>
    <style>
        body {
            font-family: 'Open Sans', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .feedback-container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
        .feedback-container h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }
        .feedback-container label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #555;
        }
        .feedback-container input[type="text"],
        .feedback-container input[type="email"],
        .feedback-container textarea,
        .feedback-container select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
            color: #333;
        }
        .feedback-container textarea {
            resize: vertical;
            height: 150px;
        }
        .feedback-container input[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #5cb85c;
            border: none;
            border-radius: 5px;
            font-size: 18px;
            color: #fff;
            cursor: pointer;
        }
        .feedback-container input[type="submit"]:hover {
            background-color: #4cae4c;
        }
    </style>
</head>
<body>
<?php include('includes/header.php');?>
<div class="feedback-container">
    <h2>Feedback Form</h2>
    <form action="feedback.php" method="POST">
        <label for="guest_name">Name</label>
        <input type="text" id="guest_name" name="guest_name" required>
        
        <label for="guest_email">Email</label>
        <input type="email" id="guest_email" name="guest_email" required>
        
        <label for="feedback_type">Feedback Type</label>
        <select id="feedback_type" name="feedback_type" required>
            <option value="Complaint">Complaint</option>
            <option value="Suggestion">Suggestion</option>
            <option value="Compliment">Compliment</option>
            <option value="Query">Query</option>
        </select>
        
        <label for="feedback_desc">Feedback Description</label>
        <textarea id="feedback_desc" name="feedback_desc" required></textarea>
        
        <input type="submit" value="Submit Feedback">
    </form>
</div>

</body>
</html>
