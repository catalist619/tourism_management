<?php
session_start();
error_reporting(0);
include('includes/config.php');
?>


<!DOCTYPE HTML>
<html>
<head>
<title>TMS | Tourism Management System</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<script type="applijewelleryion/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,700,600' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
<link href="css/font-awesome.css" rel="stylesheet">
<!-- Custom Theme files -->
<script src="js/jquery-1.12.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>
<!--//end-animate-->
</head>


<body>
<?php include('includes/header.php');?>
<div class="banner">
	<div class="container">
		<h1 class="wow zoomIn animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: zoomIn;"> TMS - Tourism Management System</h1>
	</div>
</div>


<!---holiday---->
<div class="container">
	<div class="holiday">
		<h3>Our Tours</h3> <br>


<!-- =================================== -->
<section>
	<div class="elementor-container elementor-column-gap-default">
			<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-3bd4ca0 animated fadeIn">
			<div class="elementor-widget-wrap elementor-element-populated">
				<div class="elementor-element elementor-element-83e1726 elementor-widget elementor-widget-image">
					<div class="elementor-widget-container">
						<img width="720" height="480" src="https://kwetumbalitours.com/wp-content/uploads/2024/01/stonetone.jpg"  alt="" sizes="(max-width: 720px) 100vw, 720px"> 
					</div>
				</div>
				<div class="elementor-element elementor-element-2b54712 elementor-widget elementor-widget-heading">
					<div class="elementor-widget-container">
						<h5 class="elementor-heading-title elementor-size-default">Stone Town Tour</h5>		</div>
					</div>
					<div class="elementor-element elementor-element-8c189a4 elementor-widget elementor-widget-text-editor" data-id="8c189a4" data-element_type="widget" data-widget_type="text-editor.default">
						<div class="elementor-widget-container">
							<p>Stone Town is the historic center of Zanzibar City, the capital of the Zanzibar archipelago, located off the coast of Tanzania in East Africa</p>						</div>
						</div>
						<div class="elementor-element elementor-element-3bc2493 elementor-widget elementor-widget-button" data-id="3bc2493" data-element_type="widget" data-widget_type="button.default">
							<div class="elementor-widget-container">
								<div class="elementor-button-wrapper">
									<a class="elementor-button elementor-button-link elementor-size-sm" href="stone_town.php">
										<span class="elementor-button-content-wrapper">
											<span class="elementor-button-text">learn more</span>
										</span>
									</a>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-508559c animated fadeIn">
					<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-00a4f37 elementor-widget elementor-widget-image" data-id="00a4f37" data-element_type="widget" data-widget_type="image.default">
							<div class="elementor-widget-container">
								<img loading="lazy" decoding="async" width="370" height="255" src="https://kwetumbalitours.com/wp-content/uploads/2024/01/Jozani-Forest-Tour-in-Zanzibar-1-370x255-1.jpg" class="attachment-full size-full wp-image-171" alt="" srcset="https://kwetumbalitours.com/wp-content/uploads/2024/01/Jozani-Forest-Tour-in-Zanzibar-1-370x255-1.jpg 370w, https://kwetumbalitours.com/wp-content/uploads/2024/01/Jozani-Forest-Tour-in-Zanzibar-1-370x255-1-300x207.jpg 300w" sizes="(max-width: 370px) 100vw, 370px">													
							</div>
							</div>
							<div class="elementor-element elementor-element-b1cdc63 elementor-widget elementor-widget-heading" data-id="b1cdc63" data-element_type="widget" data-widget_type="heading.default">
								<div class="elementor-widget-container">
									<h5 class="elementor-heading-title elementor-size-default">Jozani Forest Tour</h5>		</div>
								</div>
								<div class="elementor-element elementor-element-1555694 elementor-widget elementor-widget-text-editor" data-id="1555694" data-element_type="widget" data-widget_type="text-editor.default">
									<div class="elementor-widget-container">
										<p>Jozani Forest is a beautiful and ecologically important nature reserve located in the south of the island of Zanzibar</p>						</div>
									</div>
									<div class="elementor-element elementor-element-3557b32 elementor-widget elementor-widget-button" data-id="3557b32" data-element_type="widget" data-widget_type="button.default">
										<div class="elementor-widget-container">
											<div class="elementor-button-wrapper">
												<a class="elementor-button elementor-button-link elementor-size-sm" href="jozani_forest_tour.php">
													<span class="elementor-button-content-wrapper">
														<span class="elementor-button-text">learn more</span>
													</span>
												</a>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-997cef7 animated fadeIn" data-id="997cef7" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;animation&quot;:&quot;fadeIn&quot;}">
								<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-bd02642 elementor-widget elementor-widget-image" data-id="bd02642" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
													<img loading="lazy" decoding="async" width="720" height="480" src="https://kwetumbalitours.com/wp-content/uploads/2024/01/Safari-blue-1.jpg" class="attachment-full size-full wp-image-672" alt="" srcset="https://kwetumbalitours.com/wp-content/uploads/2024/01/Safari-blue-1.jpg 720w, https://kwetumbalitours.com/wp-content/uploads/2024/01/Safari-blue-1-300x200.jpg 300w, https://kwetumbalitours.com/wp-content/uploads/2024/01/Safari-blue-1-370x247.jpg 370w, https://kwetumbalitours.com/wp-content/uploads/2024/01/Safari-blue-1-270x180.jpg 270w, https://kwetumbalitours.com/wp-content/uploads/2024/01/Safari-blue-1-360x240.jpg 360w" sizes="(max-width: 720px) 100vw, 720px">													
												</div>
				</div>
				<div class="elementor-element elementor-element-78bf0eb elementor-widget elementor-widget-heading" data-id="78bf0eb" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h5 class="elementor-heading-title elementor-size-default">Safari Blue</h5>		</div>
				</div>
				<div class="elementor-element elementor-element-b03e46e elementor-widget elementor-widget-text-editor" data-id="b03e46e" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p>Safari Blue is a popular tour operator that offers a variety of activities in and around the Fumba area of Zanzibar, Tanzania.</p>						</div>
				</div>
				<div class="elementor-element elementor-element-de16722 elementor-widget elementor-widget-button" data-id="de16722" data-element_type="widget" data-widget_type="button.default">
				<div class="elementor-widget-container">
					<div class="elementor-button-wrapper">
			<a class="elementor-button elementor-button-link elementor-size-sm" href="safari_blue.php">
						<span class="elementor-button-content-wrapper">
						<span class="elementor-button-text">learn more</span>
		</span>
					</a>
		</div>
				</div>
				</div>
					</div>
		</div>
					</div>
		</section>

<!-- ================================== -->

<section>
	<div class="elementor-container elementor-column-gap-default">
			<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-3bd4ca0 animated fadeIn">
			<div class="elementor-widget-wrap elementor-element-populated">
				<div class="elementor-element elementor-element-83e1726 elementor-widget elementor-widget-image">
					<div class="elementor-widget-container">
						<img width="720" height="480" src="https://kwetumbalitours.com/wp-content/uploads/2024/01/mikumi-zebras-and-impalas-370x255-1.jpg"  alt="" sizes="(max-width: 720px) 100vw, 720px"> 
					</div>
				</div>
				<div class="elementor-element elementor-element-2b54712 elementor-widget elementor-widget-heading">
					<div class="elementor-widget-container">
						<h5 class="elementor-heading-title elementor-size-default">Mikumi National Park</h5>		</div>
					</div>
					<div class="elementor-element elementor-element-8c189a4 elementor-widget elementor-widget-text-editor" data-id="8c189a4" data-element_type="widget" data-widget_type="text-editor.default">
						<div class="elementor-widget-container">
							<p>The open horizons and abundant wildlife of the mkata floodplain .at the end of the dry seasons of the waterholes</p>	
						</div>
						</div>
						<div class="elementor-element elementor-element-3bc2493 elementor-widget elementor-widget-button" data-id="3bc2493" data-element_type="widget" data-widget_type="button.default">
							<div class="elementor-widget-container">
								<div class="elementor-button-wrapper">
									<a class="elementor-button elementor-button-link elementor-size-sm" href="mikumi.php">
										<span class="elementor-button-content-wrapper">
											<span class="elementor-button-text">learn more</span>
										</span>
									</a>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-508559c animated fadeIn">
					<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-00a4f37 elementor-widget elementor-widget-image" data-id="00a4f37" data-element_type="widget" data-widget_type="image.default">
							<div class="elementor-widget-container">
								<img loading="lazy" decoding="async" width="370" height="255" src="https://kwetumbalitours.com/wp-content/uploads/2024/01/serengeti.jpg" sizes="(max-width: 370px) 100vw, 370px">													
							</div>
							</div>
							<div class="elementor-element elementor-element-b1cdc63 elementor-widget elementor-widget-heading" data-id="b1cdc63" data-element_type="widget" data-widget_type="heading.default">
								<div class="elementor-widget-container">
									<h5 class="elementor-heading-title elementor-size-default">Ngorongoro National Park</h5>
								</div>
								</div>
								<div class="elementor-element elementor-element-1555694 elementor-widget elementor-widget-text-editor" data-id="1555694" data-element_type="widget" data-widget_type="text-editor.default">
									<div class="elementor-widget-container">
										<p>Ngorongoro crater is an experience of a lifetime. There are few places that have wildlife densities and variety on this level.</p>						</div>
									</div>
									<div class="elementor-element elementor-element-3557b32 elementor-widget elementor-widget-button" data-id="3557b32" data-element_type="widget" data-widget_type="button.default">
										<div class="elementor-widget-container">
											<div class="elementor-button-wrapper">
												<a class="elementor-button elementor-button-link elementor-size-sm" href="ngorongoro.php">
													<span class="elementor-button-content-wrapper">
														<span class="elementor-button-text">learn more</span>
													</span>
												</a>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-997cef7 animated fadeIn" data-id="997cef7" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;animation&quot;:&quot;fadeIn&quot;}">
								<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-bd02642 elementor-widget elementor-widget-image" data-id="bd02642" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
													<img loading="lazy" decoding="async" width="720" height="480" src="https://kwetumbalitours.com/wp-content/uploads/2024/01/kilimanjaro.png" sizes="(max-width: 720px) 100vw, 720px">													
												</div>
				</div>
				<div class="elementor-element elementor-element-78bf0eb elementor-widget elementor-widget-heading" data-id="78bf0eb" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h5 class="elementor-heading-title elementor-size-default">Kilimanjaro Mountain</h5>		</div>
				</div>
				<div class="elementor-element elementor-element-b03e46e elementor-widget elementor-widget-text-editor" data-id="b03e46e" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p>We may plan and provide a full service in the area of conscientious rapid air delivery of urgent, valuable.</p>						</div>
				</div>
				<div class="elementor-element elementor-element-de16722 elementor-widget elementor-widget-button" data-id="de16722" data-element_type="widget" data-widget_type="button.default">
				<div class="elementor-widget-container">
					<div class="elementor-button-wrapper">
			<a class="elementor-button elementor-button-link elementor-size-sm" href="kilimanjaro.php">
						<span class="elementor-button-content-wrapper">
						<span class="elementor-button-text">learn more</span>
		</span>
					</a>
		</div>
				</div>
				</div>
					</div>
		</div>
					</div>
		</section>

<!-- ================================== -->


					
<?php $sql = "SELECT * from tbltourpackages order by rand() limit 4";
$query = $dbh->prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{	?>
			<div class="rom-btm">
				<div class="col-md-3 room-left wow fadeInLeft animated" data-wow-delay=".5s">
					<img src="admin/pacakgeimages/<?php echo htmlentities($result->PackageImage);?>" class="img-responsive" alt="">
				</div>
				<div class="col-md-6 room-midle wow fadeInUp animated" data-wow-delay=".5s">
					<h4>Package Name: <?php echo htmlentities($result->PackageName);?></h4>
					<h6>Package Type : <?php echo htmlentities($result->PackageType);?></h6>
					<p><b>Package Location :</b> <?php echo htmlentities($result->PackageLocation);?></p>
					<p><b>Features</b> <?php echo htmlentities($result->PackageFetures);?></p>
				</div>
				<div class="col-md-3 room-right wow fadeInRight animated" data-wow-delay=".5s">
					<h5>USD <?php echo htmlentities($result->PackagePrice);?></h5>
					<a href="package-details.php?pkgid=<?php echo htmlentities($result->PackageId);?>" class="view">Details</a>
				</div>
				<div class="clearfix"></div>
			</div>

<?php }} ?>
			
		
<div><a href="package-list.php" class="view">View More Packages</a></div>
</div>
			<div class="clearfix"></div>
	</div>



<!--- routes ---->
<div class="routes">
	<div class="container">
		<div class="col-md-4 routes-left wow fadeInRight animated" data-wow-delay=".5s">
			<div class="rou-left">
				<a href="#"><i class="glyphicon glyphicon-list-alt"></i></a>
			</div>
			<div class="rou-rgt wow fadeInDown animated" data-wow-delay=".5s">
				<h3>80000</h3>
				<p>Enquiries</p>
			</div>
				<div class="clearfix"></div>
		</div>
		<div class="col-md-4 routes-left">
			<div class="rou-left">
				<a href="#"><i class="fa fa-user"></i></a>
			</div>
			<div class="rou-rgt">
				<h3>1900</h3>
				<p>Regestered users</p>
			</div>
				<div class="clearfix"></div>
		</div>
		<div class="col-md-4 routes-left wow fadeInRight animated" data-wow-delay=".5s">
			<div class="rou-left">
				<a href="#"><i class="fa fa-ticket"></i></a>
			</div>
			<div class="rou-rgt">
				<h3>7,00,00,000+</h3>
				<p>Booking</p>
			</div>
				<div class="clearfix"></div>
		</div>
		<div class="clearfix"></div>
	</div>
</div>

<?php include('includes/footer.php');?>
<!-- signup -->
<?php include('includes/signup.php');?>			
<!-- //signu -->
<!-- signin -->
<?php include('includes/signin.php');?>			
<!-- //signin -->
<!-- write us -->
<?php include('includes/write-us.php');?>			
<!-- //write us -->
</body>
</html>