<?php
session_start();
error_reporting(0);
include('includes/config.php');

?>
<!DOCTYPE HTML>
<html>
<head>
<title>TMS | Tourism Management System</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Tourism Management System In PHP" />
<script type="applijewelleryion/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,700,600' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
<link href="css/font-awesome.css" rel="stylesheet">
<!-- Custom Theme files -->
<script src="js/jquery-1.12.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>
  <style>
		.errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
		</style>
</head>
<body>
<!-- top-header -->
<div class="top-header">
<?php include('includes/header.php');?>
<div class="banner-1 ">
	<div class="container">
		<h1 class="wow zoomIn animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: zoomIn;">TMS-Tourism Management System</h1>
	</div>
</div>
<div class="privacy">
	<div class="container">


  <div style="text-align: center;">
  <img loading="lazy" decoding="async" width="800" height="480" src="https://kwetumbalitours.com/wp-content/uploads/2024/01/Safari-blue-1.jpg" class="attachment-full size-full wp-image-672" alt="" srcset="https://kwetumbalitours.com/wp-content/uploads/2024/01/Safari-blue-1.jpg 720w, https://kwetumbalitours.com/wp-content/uploads/2024/01/Safari-blue-1-300x200.jpg 300w, https://kwetumbalitours.com/wp-content/uploads/2024/01/Safari-blue-1-370x247.jpg 370w, https://kwetumbalitours.com/wp-content/uploads/2024/01/Safari-blue-1-270x180.jpg 270w, https://kwetumbalitours.com/wp-content/uploads/2024/01/Safari-blue-1-360x240.jpg 360w" sizes="(max-width: 720px) 100vw, 720px">													
  <p>Safari Blue trip is a full day tour along Menai bay, which is one of the best coral reefs in Zanzibar. Main activities in the tour includes visit to naturally occurring sandbanks, Swimming & Snorkeling in the crystal clear waters, visiting Kwale island with its natural green lagoon and Climbing the old Baobab tree for spectacular view of the Island.
If you love ocean, this tour for you. You will witness countless colorful fishes and other sea creatures that survive among the coral reefs and underwater plants which together form the barrier reef ecosystem in the bay.
During the tour enjoy the fresh seafood barbeque, Octopus, Lobsters, squids, Calamaris, Fishes. Exotic fresh fruit tasting like Banana, Watermelon, Pineapple, Mangoes. This will be the best adventurous day for your stay in Zanzibar Islands, and you will understand why we call this "Blue Safari".</p> <br> <br>
  </div>
	<center>	<h3 class="wow fadeInDown animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInDown;">BOOKING FORM</h3>

<?php include("booking.php") ?>
</center>
		
	</div>
</div>

<?php include('includes/footer.php');?>
<?php include('includes/signup.php');?>			
<?php include('includes/signin.php');?>			
<?php include('includes/write-us.php');?>

</body>
</html>